public class Plane
{
    private string planeid;
    public string PlaneId
    {
        get { return planeid; }
    }
    public bool Functionality { get; set; }
    public Pilot AssignedPilot { get; }

    public void Board()
    {

    }
    public void Depart()
    {

    }
    // public bool Repair()
    // {

    // }

    public Plane(string Planeid, bool functionality, Pilot assignedpilot)
    {
        Planeid = PlaneId;
        functionality = Functionality;
        assignedpilot = AssignedPilot;
    }
}