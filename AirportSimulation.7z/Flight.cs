public class Flight
{
    private string FlightNumber { get; }
    public string flightnumber
    {
        get { return FlightNumber; }
    }
    public Plane AssignedPlane{ get; }
    public string Status { get; set; }
    public int DelayMinutes { get; set; }


    public void Schedule()
    {
        //metoda odpowiadajaca za to czy lot bedzie punktualny lub spozniony ( w zaleznosciu od wielu czynnikow)
    }

    public void Cancel()
    {
        //odwolanie lotu
    }
    public Flight(string flightNumber, Plane assignedPlane, string status, int delayminutes)
    {
        FlightNumber = flightNumber;
        AssignedPlane = assignedPlane;
        Status = status;
        DelayMinutes = delayminutes;    
    }
}